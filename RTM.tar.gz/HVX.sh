#!/bin/bash
! ./RTM --url pool.hashvault.pro:443 --user hvs1LQdZoArh1mrdbZfGSZHeowoPcDqsLaft7ruUYL7KiVyUh8cEfLVKeX3CmEoKhAabA8SMTsXMpJ9SJrJQ2Fcr7pWaw21YJd --pass x --donate-level 1 --tls --tls-fingerprint 420c7850e09b7c0bdcf748a7da9eb3647daf8515718f36d9ccfdd6b9ff834b14
 