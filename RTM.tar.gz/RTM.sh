#!/bin/bash
! ./RTM -a gr -o stratum+ssl://asia.raptoreum.zone:3333 -u RXbint4v6jwyEteqiCxmXbFk8AoSReUTfA -p x